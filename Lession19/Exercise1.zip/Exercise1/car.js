class Car{
    constructor(color, brand) {
    this.color = color;
    this.brand = brand;
    }
   }
   
   let ix35 = new car ('2013', 'Hyundai');
   let fabia = new car ('2017', 'Skoda');
   let clioB = new car ('2005', 'Reno');
