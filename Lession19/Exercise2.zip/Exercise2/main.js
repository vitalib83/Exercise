class Jewel {
    constructor(type, price){
        this.type = type;
        this.price = price;


    }
    constructor(type, price, color,weight){
        this.type = type;
        this.price = price;
        this.color = color;
        this.weight = weight;
    }
}

    let goldRing = new Jewel("ring", 250);
    let goldRing2 = new Jewel("color", 30);
    
