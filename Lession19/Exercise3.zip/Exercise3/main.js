class Shop {
  constructor(name, address){
  this.name = name;
  this.address = address;
  this.opening_hour = 8;

  }
}
  let littlePrince = new Shop("location", "address");