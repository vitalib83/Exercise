var input = prompt("Insert a Value");
var parsedInput = parseInt(input);
if (isNaN(parsedInput)) {
    console.log(input + "!!!");
}   else{
console.log(parsedInput + 5);}..