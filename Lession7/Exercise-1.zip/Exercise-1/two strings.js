var string1 = prompt("Insert a string1");
var string2 = prompt("Insert a string2");
if (string1.toLocaleLowerCase === string2.toLocaleLowerCase) {
    console.log("True");
    
}else{
    console.log("False");
}