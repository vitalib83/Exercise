for (var counter=1; counter < 101; counter++){
    console.log(counter);
    }
    


    var counter = 1;
    while (counter <= 100){
    console.log(counter);
    counter++;   
    }