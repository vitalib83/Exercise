function findSmallest(a, b, c){
    if (a > b > c){
    return b;
} else if (a > c > b) {
    return a;
}else{
    return c;
}
}
  
findSmallest(52,66,2);
