
def get_letters5():
    return ["k", "l"]