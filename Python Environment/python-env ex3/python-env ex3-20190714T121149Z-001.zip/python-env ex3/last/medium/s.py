def get_s():
    return ["s"]