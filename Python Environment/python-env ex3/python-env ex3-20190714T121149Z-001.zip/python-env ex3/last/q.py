def get_q():
    return ["q"]