def get_letters():
    return ["t", "u", "v"]