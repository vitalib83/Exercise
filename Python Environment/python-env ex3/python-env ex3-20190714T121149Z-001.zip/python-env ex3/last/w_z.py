def get_last_letters():
    return ["w", "x", "y", "z"]