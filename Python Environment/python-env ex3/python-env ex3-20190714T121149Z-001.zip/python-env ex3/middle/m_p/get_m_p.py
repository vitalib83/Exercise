def m_p():
    return ["m", "n", "o", "p"]
