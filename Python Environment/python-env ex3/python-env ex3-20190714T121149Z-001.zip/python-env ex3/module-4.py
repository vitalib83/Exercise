
def get_letters():
    return ["h", "i", "j"]