
def get_letters():
    return ["a", "b", "c", "d", "e", "f", "g"]